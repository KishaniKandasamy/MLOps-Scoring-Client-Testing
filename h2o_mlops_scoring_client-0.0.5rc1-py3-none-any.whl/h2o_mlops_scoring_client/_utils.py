from typing import Any as _Any
from typing import Dict as _Dict
from typing import Iterator as _Iterator
from typing import List as _List
from typing import Optional as _Optional

import pandas as _pandas
import pyspark as _pyspark
import pyspark.sql as _pyspark_sql
import pyspark.sql.types as _pyspark_sql_types
import requests as _requests
from requests.adapters import HTTPAdapter as _HTTPAdapter
from urllib3.util import Retry as _Retry


class MLOpsEndpoint:
    """Python wrapper giving convenient access to H2O.ai MLOps endpoint
    information and scoring.
    """

    def __init__(self, url: str):
        url = url.rstrip("/")
        if url.endswith("model"):
            self._endpoint_parent_url = url
        else:
            self._endpoint_parent_url = "/".join(url.split("/")[:-1])
        self._capabilities_url = f"{self._endpoint_parent_url}/capabilities"
        self._experiment_id_url = f"{self._endpoint_parent_url}/id"
        self._sample_request_url = f"{self._endpoint_parent_url}/sample_request"
        self._schema_url = f"{self._endpoint_parent_url}/schema"
        self._score_url = f"{self._endpoint_parent_url}/score"

        self._capabilities = None
        self._experiment_id: _Optional[str] = None
        self._sample_request = None
        self._schema = None

        session_retry = _Retry(
            total=10,
            backoff_factor=0.5,
            status_forcelist=[403, 404],
        )
        adapter = _HTTPAdapter(max_retries=session_retry)
        self._session = _requests.Session()
        self._session.mount("http://", adapter)
        self._session.mount("https://", adapter)

        # for post to score url
        session_retry = _Retry(
            total=10,
            status_forcelist=[404, 500, 503, 504],
            backoff_factor=0.2,
            allowed_methods=["POST"],
        )
        adapter = _HTTPAdapter(max_retries=session_retry)
        self._score_session = _requests.Session()
        self._score_session.mount(self.score_url, adapter)

        self._spark_type_map = {
            "bool": _pyspark_sql_types.BooleanType(),
            "int32": _pyspark_sql_types.IntegerType(),
            "int64": _pyspark_sql_types.LongType(),
            "float32": _pyspark_sql_types.FloatType(),
            "float64": _pyspark_sql_types.DoubleType(),
            "str": _pyspark_sql_types.StringType(),
            "time64": _pyspark_sql_types.TimestampType(),
        }

    @property
    def capabilities(self) -> _List[str]:
        """Endpoint's capabilities converted to a Python list."""
        if not self._capabilities:
            r = self._session.get(self.capabilities_url)
            r.raise_for_status()
            self._capabilities = r.json()
        return self._capabilities

    @property
    def capabilities_url(self) -> str:
        """URL for retrieving endpoint's capabilities with GET method."""
        return self._capabilities_url

    @property
    def experiment_id(self) -> str:
        """Endpoint's experiment ID."""
        if not self._experiment_id:
            r = self._session.get(self._experiment_id_url)
            r.raise_for_status()
            self._experiment_id = r.text
        return self._experiment_id

    @property
    def experiment_id_url(self) -> str:
        """URL for retrieving endpoint's experiment ID with GET method."""
        return self._experiment_id_url

    @property
    def sample_request(self) -> _Dict[str, _Any]:
        """Endpoint's sample_request JSON converted to a Python dictionary."""
        if not self._sample_request:
            r = self._session.get(self.sample_request_url)
            r.raise_for_status()
            self._sample_request = r.json()
        return self._sample_request

    @property
    def sample_request_url(self) -> str:
        """URL for retrieving endpoint's sample_request with GET method."""
        return self._sample_request_url

    @property
    def schema(self) -> _Dict[str, _Any]:
        """Endpoint's full schema JSON converted to a Python dictionary."""
        if not self._schema:
            r = self._session.get(self.schema_url)
            r.raise_for_status()
            self._schema = r.json()["schema"]
        return self._schema

    @property
    def schema_spark_input(self) -> _pyspark_sql_types.StructType:
        """Endpoint's input schema JSON converted to a PySpark schema object."""
        return _pyspark_sql_types.StructType(
            [
                _pyspark_sql_types.StructField(
                    name=c["name"], dataType=self._spark_type_map[c["dataType"].lower()]
                )
                for c in self.schema["inputFields"]
            ]
        )

    @property
    def schema_spark_output(self) -> _pyspark_sql_types.StructType:
        """Endpoint's output schema JSON converted to a PySpark schema object."""
        return _pyspark_sql_types.StructType(
            [
                _pyspark_sql_types.StructField(
                    name=c["name"], dataType=self._spark_type_map[c["dataType"].lower()]
                )
                for c in self.schema["outputFields"]
            ]
        )

    @property
    def schema_url(self) -> str:
        """URL for retrieving endpoint's schema with GET method."""
        return self._schema_url

    @property
    def score_url(self) -> str:
        """URL for endpoint scoring with POST method."""
        return self._score_url

    def score_pandas_dataframe(
        self, pdf: _pandas.DataFrame, id_column: _Optional[str] = None
    ) -> _pandas.DataFrame:
        """Score a Pandas DataFrame as long as the size does not exceed the
        maximum request size of the endpoint.
        """

        payload = dict(
            fields=list(pdf.columns),
            rows=pdf.fillna("").astype(str).to_dict("split")["data"],
        )
        if id_column:
            payload["includeFieldsInOutput"] = [id_column]
        result = self._score_session.post(url=self.score_url, json=payload, timeout=60)
        result.raise_for_status()
        result_dataframe = _pandas.DataFrame(
            data=result.json()["score"], columns=result.json()["fields"]
        ).astype(float, errors="ignore")
        # need to filter fields as schema sometimes doesn't include bounds for
        # regression intervals
        output_columns = []
        if id_column:
            output_columns.append(id_column)
        output_columns.extend([c["name"] for c in self.schema["outputFields"]])
        result_dataframe = result_dataframe[output_columns]

        return result_dataframe

    def score_spark_dataframe(
        self, sdf: _pyspark_sql.DataFrame, id_column: str
    ) -> _pyspark_sql.DataFrame:
        """Score a Spark DataFrame of any size in mini-batches (requires Spark 3).

        Batch size is determined by the Spark config
        "spark.sql.execution.arrow.maxRecordsPerBatch".
        Larger mini-batch sizes can process quicker but may exceed the maximum
        request size of the endpoint. Recommended starting mini-batch size is 1000.
        """

        def score_pandas_dataframe_spark(
            iterator: _Iterator[_pandas.DataFrame],
        ) -> _Iterator[_pandas.DataFrame]:
            for pdf in iterator:
                yield self.score_pandas_dataframe(pdf, id_column)

        input_columns = [id_column] + [c["name"] for c in self.schema["inputFields"]]
        output_schema = _pyspark_sql_types.StructType(
            [sdf.schema[id_column]] + [f for f in self.schema_spark_output]
        )
        scores = sdf.select(input_columns).mapInPandas(
            score_pandas_dataframe_spark, schema=output_schema  # type: ignore
        )
        # ^ mypy says incompatible type and I don't know how to fix it

        return scores


def get_spark_session(
    app_name: str = "mlops_spark_scorer_job",
    mini_batch_size: int = 1000,
    master: _Optional[str] = None,
    spark_config: _Optional[_Dict[str, _Any]] = None,
) -> _pyspark_sql.SparkSession:
    if not spark_config:
        spark_config = {}
    conf = _pyspark.SparkConf()
    conf.setAppName(app_name)
    if master:
        conf.setMaster(master)
    if master and master.startswith("local"):
        driver_memory = conf.get("spark.driver.memory", "5g")
        conf.set("spark.driver.memory", driver_memory)
    conf.set("spark.sql.execution.arrow.pyspark.enabled", "true")
    conf.set("spark.sql.execution.arrow.maxRecordsPerBatch", str(mini_batch_size))
    conf.setAll([(k, str(v)) for k, v in spark_config.items()])
    spark = _pyspark_sql.SparkSession.builder.config(conf=conf).getOrCreate()
    return spark


def read_source(
    spark: _pyspark_sql.SparkSession,
    data: str,
    config: _Optional[_Dict[str, str]] = None,
) -> _pyspark_sql.DataFrame:
    if not config:
        config = {}
    return spark.read.load(data, **config)


def score(
    mlops_endpoint: MLOpsEndpoint,
    id_column: str,
    df: _pyspark_sql.DataFrame,
    num_partitions: _Optional[int] = None,
) -> _pyspark_sql.DataFrame:
    if num_partitions:
        df = df.repartition(num_partitions)
    return mlops_endpoint.score_spark_dataframe(df, id_column=id_column)


def write_sink(
    df: _pyspark_sql.DataFrame,
    location: str,
    mode: str,
    config: _Optional[_Dict[str, str]] = None,
) -> None:
    if not config:
        config = {}
    df.write.mode(mode).save(location, **config)
